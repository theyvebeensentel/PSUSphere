**Heya** This is a sample **Django** & **Faker** implimentations: 
**Just a Readme File** _by: Arjay_

#[https://arjay1412.pythonanywhere.com/]
