from pathlib import Path
import sqlite3

DB_PATH = Path(__file__).resolve().parent.parent / 'projectsite' / 'db.sqlite3'

def list_superusers(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, email FROM auth_user WHERE is_superuser=1")
    users = cursor.fetchall()
    print("Superusers:")
    for user in users:
        print(f"ID: {user[0]}, Username: {user[1]}, Email: {user[2]}")
    return users

def update_superuser_field(conn, user_id, field, new_value):
    if field not in ['username', 'email', 'first_name', 'last_name']:
        print(f"Field '{field}' cannot be updated directly or is not supported.")
        return
    cursor = conn.cursor()
    query = f"UPDATE auth_user SET {field} = ? WHERE id = ?"
    cursor.execute(query, (new_value, user_id))
    conn.commit()
    print(f"Updated user ID {user_id}: set {field} = {new_value}")

def main():
    conn = sqlite3.connect(DB_PATH)
    users = list_superusers(conn)
    if not users:
        print("No superusers found.")
        return

    user_id = int(input("Enter the ID of the superuser to edit: "))
    fields = ['username', 'email', 'first_name', 'last_name']
    print("Fields you can update:", fields)
    field = input("Enter the field to update: ")
    if field not in fields:
        print("Invalid field.")
        return
    new_value = input(f"Enter the new value for {field}: ")
    update_superuser_field(conn, user_id, field, new_value)
    conn.close()

if __name__ == "__main__":
    main()
